<?php

namespace Drupal\blazy_test;

/**
 * Defines re-usable services and functions for blazy test field plugins.
 */
interface BlazyFormatterTestInterface {}
