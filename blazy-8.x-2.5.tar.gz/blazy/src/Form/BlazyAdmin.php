<?php

namespace Drupal\blazy\Form;

/**
 * Provides admin form specific to Blazy admin.
 */
class BlazyAdmin extends BlazyAdminBase {}
